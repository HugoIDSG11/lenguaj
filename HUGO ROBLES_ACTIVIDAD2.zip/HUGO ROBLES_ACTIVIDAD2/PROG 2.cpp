#include <iostream>
using namespace std;

int main() {
    float primer_numero, segundo_numero;

    cout << "Escribe el primer número: ";
    cin >> primer_numero;

    cout << "Escribe el segundo número: ";
    cin >> segundo_numero;

    float suma = primer_numero + segundo_numero;
    float resta = primer_numero - segundo_numero;
    float multiplicacion = primer_numero * segundo_numero;

    float division;
    if (segundo_numero != 0) {
        division = primer_numero / segundo_numero;
    } else {
        division = 0; // Para evitar divisiones entre cero
        cout << "Advertencia: No se puede dividir entre cero." << endl;
    }

    // Mostrar resultados
    cout << "La suma es: " << suma << endl;
    cout << "La resta es: " << resta << endl;
    cout << "La multiplicación es: " << multiplicacion << endl;
    cout << "La división es: " << division << endl;

    return 0;
}
